package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class SSNService {

	public void validateSSN() {
		// TODO Auto-generated method stub
		
	}

}
