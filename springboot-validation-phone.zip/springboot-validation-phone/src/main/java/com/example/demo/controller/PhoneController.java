package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.PhoneService;

@RestController
public class PhoneController {

	@Autowired
	private PhoneService phoneService;

	@RequestMapping(value = "/validatePhone", method = RequestMethod.GET)
	public String validatePhone() {
		phoneService.validatePhone();
		return "validated";
	}

}
