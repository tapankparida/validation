package com.validate.controller;

import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.validate.model.User;
import com.validate.service.AsyncValidateService;
import com.validate.service.UserService;

@RestController
@RequestMapping("/api/")
@EnableAsync
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	AsyncValidateService asyncService;

	@PostMapping("users")
	public ResponseEntity<User> createUser(@Valid @RequestBody User user) throws ExecutionException {
		String traceID = UUID.randomUUID().toString();
		long start = System.currentTimeMillis();
		try {
			Future<String> futureResultSSN = asyncService.validateSSN();
			Future<String> futureResultEmail = asyncService.validateEmail();
			Future<String> futureResultPhone = asyncService.validatePhone();
			String resultSSN = futureResultSSN.get();
			String resultEmail = futureResultEmail.get();
			String resultPhone = futureResultPhone.get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String response = "task completes in :" + 
			      (System.currentTimeMillis() - start) + "milliseconds";
		System.out.println("response-- "+response);
		User savedUser = userService.createUser(user);
		savedUser.setCustomerId(traceID);
		return new ResponseEntity<User>(savedUser, HttpStatus.CREATED);
	}

}
