package com.validate.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Table(name = "users")
@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "name", nullable = false)
	@NotEmpty
	@Size(min = 2, message = "user name should have at least 2 characters")
	private String name;

	@NotEmpty
	@Pattern(regexp = "^[0-9][0-9]{2}-[0-9]{2}-[0-9]{4}$", message = "SSN must use numbers in this format: XXX-YY-ZZZZ")
	private String ssn;

	@NotNull
//	@Min(10)
//	@Max(10)
	private Integer phone;

	@NotEmpty
	@Email
	private String email;

//	@NotNull(message = "The date of birth is required.")
//	@BirthDate(message = "The birth date must be greater or equal than 18")
//	@Past(message = "The date of birth must be in the past.")
	private Date dateOfBirth;

	private String customerId;
	
	public User() {

	}
	
	public User(long id, @NotEmpty @Size(min = 2, message = "user name should have at least 2 characters") String name,
			@NotEmpty @Pattern(regexp = "^[0-9][0-9]{2}-[0-9]{2}-[0-9]{4}$", message = "SSN must use numbers in this format: XXX-YY-ZZZZ") String ssn,
			@NotNull @Size(min = 10, max = 10) Integer phone, @NotEmpty @Email String email,
			@NotNull(message = "The date of birth is required.") @Past(message = "The date of birth must be in the past.") Date dateOfBirth,
			@NotEmpty @Size(min = 8, message = "password should have at least 8 characters") String password) {
		super();
		this.id = id;
		this.name = name;
		this.ssn = ssn;
		this.phone = phone;
		this.email = email;
		this.dateOfBirth = dateOfBirth;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public Integer getPhone() {
		return phone;
	}

	public void setPhone(Integer phone) {
		this.phone = phone;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

}
