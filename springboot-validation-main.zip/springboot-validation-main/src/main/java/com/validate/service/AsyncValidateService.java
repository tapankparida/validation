package com.validate.service;

import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AsyncValidateService {

	@Lazy
	@Autowired
	private RestTemplate restTemplate;

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Async("asyncExecutor")
	public Future<String> validateSSN() throws InterruptedException {
		Thread.sleep(13000);
		
		System.out.println("Calling validateSSN service..");
		System.out.println("Thread: " + Thread.currentThread().getName());
		
		String isValidated = restTemplate.getForObject("http://localhost:8083/validateSSN", String.class);

		return new AsyncResult<String>(isValidated);
	}

	@Async("asyncExecutor")
	public Future<String> validatePhone() throws InterruptedException {
		Thread.sleep(4000);
		
		System.out.println("Calling validatePhone service..");
		System.out.println("Thread: " + Thread.currentThread().getName());
		
		String isValidated = restTemplate.getForObject("http://localhost:8082/validatePhone", String.class);
		
		return new AsyncResult<String>(isValidated);

	}

	@Async("asyncExecutor")
	public Future<String> validateEmail() throws InterruptedException {
		Thread.sleep(5000);

		System.out.println("Calling validateEmail service..");
		System.out.println("Thread: " + Thread.currentThread().getName());

		String isValidated = restTemplate.getForObject("http://localhost:8081/validateEmail", String.class);

		return new AsyncResult<String>(isValidated);
	}
}
