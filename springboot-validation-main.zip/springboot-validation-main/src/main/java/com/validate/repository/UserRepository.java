package com.validate.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.validate.model.User;

public interface UserRepository extends JpaRepository<User, Long>{

}
