package com.validate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
